﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Matiere
    {
        private string nom;
        private List<Prof> lesProfsHabilites;

        public Matiere(string nom)
        {
            this.Nom = nom;
            this.LesProfsHabilites = new List<Prof>();
        }

        public string Nom { get => nom; set => nom = value; }
        public List<Prof> LesProfsHabilites { get => lesProfsHabilites; set => lesProfsHabilites = value; }

        public void ajouerProfHabilite(Prof p)
        {
            this.LesProfsHabilites.Add(p);
        }
    }
}
