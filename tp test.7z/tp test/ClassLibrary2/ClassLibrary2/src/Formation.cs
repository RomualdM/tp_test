﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Formation
    {
        private string nom;
        private List<Etudiant> lesEtudiants;
        private List<Enseignement> lesEnseignements;

        public Formation()
            {
            this.lesEtudiants = new List<Etudiant>();
            this.lesEnseignements = new List<Enseignement>();
            }
        public string Nom { get => nom; set => nom = value; }
        public List<Etudiant> LesEtudiants { get => lesEtudiants; set => lesEtudiants = value; }
        public List<Enseignement> LesEnseignements { get => lesEnseignements; set => lesEnseignements = value; }

        /// <summary>
        /// Ajoute un étudiant dans la formation
        /// </summary>
        public void ajouterEtudiant(Etudiant et)
        {
            this.LesEtudiants.Add(et);
        }

        /// <summary>
        /// Méthode qui récupère les étudiants admis (ceux qui ont la moyenne générale)
        /// </summary>
        /// <returns>LA liste des étudiants admis</returns>
        public List<Etudiant> lesAdmis()
        {
            List<Etudiant> admis = new List<Etudiant>();
            foreach(Etudiant e in LesEtudiants)
            {
                
                if (e.CalculerMoyenneEtudiant() > 9)
                {
                    admis.Add(e);
                }

            }
            return admis;
        }

        /// <summary>
        /// Tri les étudiants selon un critère défini. 
        /// </summary>
        /// <param name="critere">critère pouvant être "alpha" ou "classement" selon les moyenne générale</param>
        public void trierLesEtudiants(string critere)
        {
            // à écrire
        }

        /// <summary>
        /// Retourne la moyenne générale de classe
        /// </summary>
        /// <returns></returns>
        /// 
       
        public double calculerMoyenneGenerale()
        {
            double total = 0;
            int nbnote = 0;
            foreach (Etudiant e in LesEtudiants)
            {
                total += e.CalculerMoyenneEtudiant();
                nbnote++;
            }
            return total / nbnote;
        }
    }
}
