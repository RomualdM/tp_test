﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClassLibrary2
{
    public class Prof : Personne
    {
        private string nom;
        private string prenom;
        private string status; // contractuel ou titulaire

        private List<Enseignement> lesEnseignements;

        public Prof(string nom, string prenom, string stat) : base (nom, prenom)
        {
            this.status = stat;
            this.LesEnseignements = new List<Enseignement>() ;
        }

        public List<Enseignement> LesEnseignements { get => lesEnseignements; set => lesEnseignements = value; }



        /// <summary>
        /// AJoute un enseignement au prof
        /// </summary>
        /// <param name="ens"></param>
        public void ajouterEnseignement(Enseignement ens)
        {
            this.LesEnseignements.Add(ens);
        }
    }
}
