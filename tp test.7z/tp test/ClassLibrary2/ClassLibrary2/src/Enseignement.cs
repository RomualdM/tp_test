﻿using System.Collections.Generic;

namespace ClassLibrary2
{
    public class Enseignement
    {
        private bool facultatif;
        private Matiere laMatiere;
        private Prof leProf;
        private List<Etudiant> lesEtudiants;
        private Formation laFormation;
        private List<Evaluation> lesEvaluations;

        public Enseignement(bool facultatif, Matiere laMatiere, Prof leProf, Formation laForm)
        {
            this.facultatif = facultatif;
            this.laMatiere = laMatiere;
            this.leProf = leProf;
            this.LaFormation = laForm;
            this.lesEtudiants = new List<Etudiant>();
            this.LesEvaluations = new List<Evaluation>();
        }

        public Enseignement()
        {
            this.lesEtudiants = new List<Etudiant>();
            this.LesEvaluations = new List<Evaluation>();
        }

        public bool Facultatif { get => facultatif; set => facultatif = value; }
        public List<Etudiant> LesEtudiants { get => lesEtudiants; set => lesEtudiants = value; }
        public Matiere LaMatiere { get => laMatiere; set => laMatiere = value; }
        public Prof LeProf { get => leProf; set => leProf = value; }
        public Formation LaFormation { get => laFormation; set => laFormation = value; }
        public List<Evaluation> LesEvaluations { get => lesEvaluations; set => lesEvaluations = value; }

        /// <summary>
        /// Ajoute une évaluation d'un étudiant dans une matière donnée
        /// </summary>
        /// <param name="eval"></param>
        public void ajouterEvaluation(Evaluation eval)
        {
            this.LesEvaluations.Add(eval);
        }
    }
}
