﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Etudiant : Personne
    {
        private string code;
        private Formation laFormationSuivie;

        public Etudiant(string nom, string prenom, string code) : base(nom, prenom)
        {
            this.Code = code;
        }

        public string Code { get => code; set => code = value; }
        public Formation LaFormationSuivie { get => laFormationSuivie; set => laFormationSuivie = value; }

        public double CalculerMoyenneEtudiant()
        {
            double total = 0;
            int nbnote = 0;
            double moyenne = 0;
            foreach (Enseignement en in this.LaFormationSuivie.LesEnseignements)
            {
                for (int i = 0; i < en.LesEvaluations.Count; i++)
                {
                    total += en.LesEvaluations[i].LaNote* en.LesEvaluations[i].LeCoeff;
                    nbnote += en.LesEvaluations[i].LeCoeff;
                    
                }
               
            }
            moyenne = total / nbnote;
            return moyenne;
        }
    }
}
