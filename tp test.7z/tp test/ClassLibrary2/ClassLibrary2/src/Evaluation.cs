﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Evaluation
    {
        private Etudiant lEtudiant;
        private Matiere laMatiere;
        private double laNote;
        private int leCoeff;

        public Evaluation(Etudiant lEtudiant, Matiere laMatiere, double laNote, int leCoeff)
        {
            this.LEtudiant = lEtudiant;
            this.LaMatiere = laMatiere;
            this.LaNote = laNote;
            this.LeCoeff = leCoeff;
        }

        public Etudiant LEtudiant { get => lEtudiant; set => lEtudiant = value; }
        public double LaNote { get => laNote; set => laNote = value; }
        public int LeCoeff { get => leCoeff; set => leCoeff = value; }
        public Matiere LaMatiere { get => laMatiere; set => laMatiere = value; }
    }
}
