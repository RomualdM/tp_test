﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using ClassLibrary2;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void testAjoutEnseignement()
        {

            Formation f = new Formation();
            
            Prof p = new Prof("Charles", "Jean", "titulaire");
            
            Matiere m = new Matiere("c#");

            Enseignement en = new Enseignement(false, m, p, f);

            p.ajouterEnseignement(en);

            Assert.AreEqual(1, p.LesEnseignements.Count, "la liste ne contient rien");

            Assert.AreEqual(en, p.LesEnseignements[0], "l'enseignement récuperé n'est pas le bon");
            
            
        }


        [TestMethod]
       public void TestAjoutEtudiant()
        {
            Formation f = new Formation();
            Etudiant e = new Etudiant("Grange","Jean","abcde");

            f.ajouterEtudiant(e);

            Assert.AreEqual(1, f.LesEtudiants.Count, "la liste ne contient rien");
            Assert.AreEqual(e, f.LesEtudiants[0],"l'étudiant récuperé n'est pas le bon");

            Etudiant e2 = new Etudiant("Talu","Jean","12345");

            f.ajouterEtudiant(e2);

            Assert.AreEqual(2,f.LesEtudiants.Count,"la liste ne contient pas 2 etudiants");
            Assert.AreEqual(e2,f.LesEtudiants[1],"l'étudiant récuperé n'est pas le bon 2");
        }

        [TestMethod]
        public void testAjouterEvaluation()
        {
            Etudiant et = new Etudiant("Grange", "Jean", "abcde");
            Etudiant et2 = new Etudiant("talu", "jean", "12345");
            Matiere m = new Matiere("c#");
            Evaluation e = new Evaluation(et,m,15,2);
            Evaluation e2 = new Evaluation(et2, m, 5, 12);
            Enseignement en = new Enseignement();

            en.ajouterEvaluation(e);

            Assert.AreEqual(1, en.LesEvaluations.Count,"La liste ne contient rien");
            Assert.AreEqual(e, en.LesEvaluations[0], "l'évaluation récuperée n'est pas la bonne");

            en.ajouterEvaluation(e2);

            Assert.AreEqual(2, en.LesEvaluations.Count, "La liste ne contient pas 2 évaluations");
            Assert.AreEqual(e2, en.LesEvaluations[1], "la 2ème évaluation récuperée n'est pas la bonne");
            
        }
        [TestMethod]
        public void testAjoutProf()
        {
            Matiere m = new Matiere("c#");
            Prof p = new Prof("Charles", "Jean", "titulaire");

            m.ajouerProfHabilite(p);

            Assert.AreEqual(1, m.LesProfsHabilites.Count, "La liste ne contient pas 2 évaluations");
            Assert.AreEqual(p, m.LesProfsHabilites[0], "le Prof récuperée n'est pas le bon");

        }
        [TestMethod]
        public void testCalculMoyenneEtudiant()
        {
            Formation f = new Formation();
            Matiere mat = new Matiere("sql");
            Etudiant e = new Etudiant("Charles","Jean","abcde");
            e.LaFormationSuivie = f;
            Enseignement ens = new Enseignement();
            Evaluation ev1 = new Evaluation(e,mat,10,2);
            Evaluation ev2 = new Evaluation(e, mat, 10, 2);
            Evaluation ev3 = new Evaluation(e, mat, 10, 5);
            Evaluation ev4 = new Evaluation(e, mat, 10, 2);
            ens.ajouterEvaluation(ev1);
            ens.ajouterEvaluation(ev2);
            ens.ajouterEvaluation(ev3);
            ens.ajouterEvaluation(ev4);
            f.LesEnseignements.Add(ens);

            Assert.AreEqual(10, e.CalculerMoyenneEtudiant(), "La moyenne retrouvée n'est pas bonne");
            
        }
        [TestMethod]
        public void testCalculMoyenneGenerale()
        {
            Formation f = new Formation();
            Matiere mat = new Matiere("sql");
            Etudiant e = new Etudiant("Charles", "Jean", "abcde");
            Etudiant e2 = new Etudiant("talu", "Jean", "12345");
            Etudiant e3 = new Etudiant("preinte", "jean", "77777");
            e.LaFormationSuivie = f;
            e2.LaFormationSuivie = f;
            e3.LaFormationSuivie = f;
            Enseignement ens = new Enseignement();
            Evaluation ev1 = new Evaluation(e, mat, 10, 2);
            Evaluation ev2 = new Evaluation(e, mat, 10, 2);
            Evaluation ev3 = new Evaluation(e, mat, 10, 5); 
            Evaluation ev4 = new Evaluation(e, mat, 10, 2);
            Evaluation ev5 = new Evaluation(e2, mat, 15, 2);
            Evaluation ev6 = new Evaluation(e2, mat,15, 2);              
            Evaluation ev7 = new Evaluation(e2, mat, 15, 2);
            Evaluation ev8 = new Evaluation(e2, mat, 15, 2);
            Evaluation ev9 = new Evaluation(e3, mat, 5, 2);
            Evaluation ev10 = new Evaluation(e3, mat, 5, 2); 
            Evaluation ev11 = new Evaluation(e3, mat, 5, 2);
            Evaluation ev12 = new Evaluation(e3, mat, 5, 2);
            
            ens.ajouterEvaluation(ev1);
            ens.ajouterEvaluation(ev2);
            ens.ajouterEvaluation(ev3);
            ens.ajouterEvaluation(ev4);
            ens.ajouterEvaluation(ev5);
            ens.ajouterEvaluation(ev6);
            ens.ajouterEvaluation(ev7);
            ens.ajouterEvaluation(ev8);
            ens.ajouterEvaluation(ev9);
            ens.ajouterEvaluation(ev10);
            ens.ajouterEvaluation(ev11);
            ens.ajouterEvaluation(ev12);
            f.LesEnseignements.Add(ens);
            f.LesEtudiants.Add(e);
            f.LesEtudiants.Add(e2);
            f.LesEtudiants.Add(e3);

            Assert.AreEqual(10, f.calculerMoyenneGenerale(), "la moyenne trouvée n'est pas la bonne");

        }
        [TestMethod]
        public void testLesAdmis()
        {
            Formation f = new Formation();
            Matiere mat = new Matiere("sql");
            Etudiant e = new Etudiant("Charles", "Jean", "abcde");
            Etudiant e2 = new Etudiant("talu", "Jean", "12345");
            Etudiant e3 = new Etudiant("preinte", "jean", "77777");
            e.LaFormationSuivie = f;
            e2.LaFormationSuivie = f;
            e3.LaFormationSuivie = f;
            Enseignement ens = new Enseignement();
            Evaluation ev1 = new Evaluation(e, mat, 10, 2);
            Evaluation ev2 = new Evaluation(e, mat, 10, 2);
            Evaluation ev3 = new Evaluation(e, mat, 10, 5);
            Evaluation ev4 = new Evaluation(e, mat, 10, 2);

            Evaluation ev5 = new Evaluation(e2, mat, 15, 2);
            Evaluation ev6 = new Evaluation(e2, mat, 15, 2);
            Evaluation ev7 = new Evaluation(e2, mat, 15, 2);
            Evaluation ev8 = new Evaluation(e2, mat, 15, 2);

            Evaluation ev9 = new Evaluation(e3, mat, 5, 2);
            Evaluation ev10 = new Evaluation(e3, mat, 5, 2);
            Evaluation ev11 = new Evaluation(e3, mat, 5, 2);
            Evaluation ev12 = new Evaluation(e3, mat, 5, 2);

            ens.ajouterEvaluation(ev1);
            ens.ajouterEvaluation(ev2);
            ens.ajouterEvaluation(ev3);
            ens.ajouterEvaluation(ev4);
            ens.ajouterEvaluation(ev5);
            ens.ajouterEvaluation(ev6);
            ens.ajouterEvaluation(ev7);
            ens.ajouterEvaluation(ev8);
            ens.ajouterEvaluation(ev9);
            ens.ajouterEvaluation(ev10);
            ens.ajouterEvaluation(ev11);
            ens.ajouterEvaluation(ev12);
            f.LesEnseignements.Add(ens);
            f.ajouterEtudiant(e);
            f.ajouterEtudiant(e2);
            f.ajouterEtudiant(e3);

            List<Etudiant> le = new List<Etudiant>();
            le.Add(e);
            le.Add(e2);


            // Assert.AreEqual(2, f.lesAdmis().Count, "Il n'y a pas le meme nombre d'admis");
            Assert.AreEqual(6, f.LesEtudiants[2].CalculerMoyenneEtudiant(), "non");
            
            
            // Assert.AreSame(le[0], f.lesAdmis()[0], "les etudiants ne sont pas les mêmes");
        }
        
    }
}
